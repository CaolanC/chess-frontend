import { Board } from './Board';
import { Position } from './Utils';
import { Application, Graphics, roundPixelsBit, Sprite, HTMLText, Assets } from "pixi.js";

enum PieceImagePaths {
    Pawn = "/images/pawn.svg"
}

export class Piece {

    protected readonly image_path: string;

    constructor(piece : string) {
        this.image_path = PieceImagePaths.Pawn;
    }

    public getImagePath() : string {
        return this.image_path;
    }

    public async draw(app: Application, square_size: number, row: number, col: number) {
        const texture = await Assets.load([this.image_path]);
        const sprite = new Sprite(texture);

        sprite.anchor.set(0.5);
        sprite.x = col * square_size + (square_size / 2);
        sprite.y = row * square_size + (square_size / 2);

        app.stage.addChild(sprite);
    }

    public ReRender(app: Application) {
    }

    protected _isBlack(piece : string) {         // checks if its lowercase(black)
        return piece === piece.toLowerCase() &&
        piece !== piece.toUpperCase();  
    }

}

// CAOLANS OLD CODE, MAYBE REUSABLE

// export class Piece
// {
//     protected readonly ID: string;
//     protected Board: Board;

//     public Position: Position;

//     constructor(
//             iswhite : boolean,
//             id: string, 
//             board: Board, 
//             position: Position,
//             type : string,
//     ) {
//         //this.Namespace = namespace, // Namespacing and ID's are so that we can uniquely identify a piece's sprite on the backend without storing it in the engine instance
//         this.ID = id;
//         this.Board = board;
//         this.Position = position;
//     }


//     public getId(): string {
//         return this.ID;
//     }

// }
